package TDAs;

public interface Stack<E>{
    public int size();
    public boolean isEmpty();
    public E top();
    public E pop();
    public void push(E e);

}
